﻿using DocumentFormat.OpenXml.Vml;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Text;

namespace OpenXML.Models

{
    public class Student
    {
        public string StudentCode { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }

        private string _DateOfBirthString;
        public string DateOfBirthString
        {
            get
            {
                return _DateOfBirthString;
            }
            set
            {
                _DateOfBirthString = value;

                DateTime datetime;
                if (DateTime.TryParse(_DateOfBirthString, out datetime) == true)
                {
                    DateOfBirth = datetime;
                }
            }
        }
        public DateTime DateOfBirth { get; set; }
        public string ImageData { get; private set; }

        private string _ImageData;


        public void FromDirectory(string directory)
        {
            try
            {
                //Split directory into parts, use space as separator
                //Use None to avoid losing data due to errors
                string[] directoryPart = directory.Split(" ", StringSplitOptions.None);

                StudentCode = directoryPart[0];
                FirstName = directoryPart[1];
                LastName = directoryPart[2];
            }
            catch (Exception e)
            {

            }
        }
        
        public override string ToString()
        {
            //Format of contents
            return $"{StudentCode}- {LastName}, {FirstName}";
        }

        public void FromCSV(string csvDataLine)
        {
            try
            {
                //Split directory into parts, use space as separator
                //Use None to avoid losing data due to errors
                string[] csvDataLineParts = csvDataLine.Split(",", StringSplitOptions.None);

                StudentCode = csvDataLineParts[0];
                FirstName = csvDataLineParts[1];
                LastName = csvDataLineParts[2];
                DateOfBirth = Convert.ToDateTime(csvDataLineParts[3]);
                ImageData = csvDataLineParts[4];
            }
            catch (Exception e)
            {
                // Console.WriteLine(e.Message
            }


        }
    }


}

 
