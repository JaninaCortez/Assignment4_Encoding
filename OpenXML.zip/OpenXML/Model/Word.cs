﻿using System;
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Wordprocessing;

namespace Sample
{
    class Program
    {
        static void Main (string[] args)
        {
            // Create a document by path, and write some text in it.  
            string fileName = @"C:\Users\corte\source\repos\OpenXML\info.docx";
            string txt = "Hello, my name is";

            // Create the Word document.   
            WordprocessingDocument wordprocessingDocument =
                WordprocessingDocument.Create(fileName,
                    WordprocessingDocumentType.Document);

            // Create a MainDocumentPart instance.  
            MainDocumentPart mainDocumentPart =
                wordprocessingDocument.AddMainDocumentPart();
            mainDocumentPart.Document = new Document();

            // Create a Document instance.  
            Document document = mainDocumentPart.Document;

            // Create a Body instance.  
            Body body = document.AppendChild(new Body());

            // Create a Paragraph instance.  
            Paragraph para = body.AppendChild(new Paragraph());

            // Create a Run instance.  
            Run run = para.AppendChild(new Run());

            // Add Text to the Run element.  
            run.AppendChild(new Text(txt));

            // Close the document handle  
            wordprocessingDocument.Close();

            Console.WriteLine("The document has been created. Press any key.");
            Console.ReadKey();
        }
    }
}
